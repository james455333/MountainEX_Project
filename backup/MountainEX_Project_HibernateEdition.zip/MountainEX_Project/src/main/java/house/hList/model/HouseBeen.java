package house.hList.model;

public class HouseBeen {

	String mountainname;
	String name;
	Integer seat;
	Integer campseat;
	String hight;
	
	public String getMountainName() {
		return mountainname;
	}
	public void setMountainName(String mountainname) {
		this.mountainname = mountainname;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getSeat() {
		return seat;
	}
	public void setSeat(Integer seat) {
		this.seat = seat;
	}
	public Integer getCampSeat() {
		return campseat;
	}
	public void setCampSeat(Integer campseat) {
		this.campseat = campseat;
	}
	public String getHight() {
		return hight;
	}
	public void setHight(String hight) {
		this.hight = hight;
	}
	
	
	
}
