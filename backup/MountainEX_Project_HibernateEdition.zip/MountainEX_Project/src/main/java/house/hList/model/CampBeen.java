package house.hList.model;

public class CampBeen {

	String city;
	String camptown;
	String campname;
	String campdesc;
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCamptown() {
		return camptown;
	}
	public void setCamptown(String camptown) {
		this.camptown = camptown;
	}
	public String getCampname() {
		return campname;
	}
	public void setCampname(String campname) {
		this.campname = campname;
	}
	public String getCampdesc() {
		return campdesc;
	}
	public void setCampdesc(String campdesc) {
		this.campdesc = campdesc;
	}
	
}
