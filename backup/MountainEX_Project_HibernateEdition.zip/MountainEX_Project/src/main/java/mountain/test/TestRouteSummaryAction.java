package mountain.test;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import mountain.mountainList.model.RouteSummary;
import mountain.mountainList.service.RouteSummaryService;
import util.HibernateUtil;

public class TestRouteSummaryAction {
	
	public static void main(String[] args) {
		
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.getCurrentSession();
		
		try {
			session.beginTransaction();
			
			RouteSummaryService routeSummaryService = new RouteSummaryService(session);
			List<RouteSummary> selectAll = routeSummaryService.selectAll();
			for (RouteSummary routeSummary : selectAll) {
				System.out.println("Name : " + routeSummary.getName() + "\tNP_Name : " + routeSummary.getNpName());
			}
			
			session.getTransaction().commit();
		} catch (Exception e) {
			session.getTransaction().rollback();
			e.printStackTrace();
		}
		
		
		
	}

}
