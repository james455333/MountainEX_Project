package platform.model;

public class GroupBean {
	String subject;
	String time;
	String username;
	String lasttime;
int colum_5;
}
