package platform.model;

public class TestBean {
	String name;
	int id;

}
