package platform.model;

public class AllsubjectBean {
	String subject;
	String time;
	String username;
	String lasttime;
	int colum;
}
