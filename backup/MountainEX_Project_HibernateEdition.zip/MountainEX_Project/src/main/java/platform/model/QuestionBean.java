package platform.model;

public class QuestionBean {
	String subject;
	String time;
	String username;
	String lasttime;
	int colum_5_4;
}
