package platform.model;

public class LostBean {
	String subject;
	String time;
	String username;
	String lasttime;
	int colum_5_3;
}
