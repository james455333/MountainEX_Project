
$("#act_back_button").on("click",function(){
	history.back(-1);
})
