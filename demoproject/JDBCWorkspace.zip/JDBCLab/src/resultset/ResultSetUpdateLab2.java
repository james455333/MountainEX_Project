package resultset;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class ResultSetUpdateLab2 {

	public static void main(String[] args)  {
		try(
			Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/xepdb1", "scott", "tiger");
			Statement stmt = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet rs = stmt.executeQuery("select e.* from emp e");) {
			
//			rs.absolute(11);
//			rs.deleteRow();
			//實務上幾乎用不到 使用executeUpdate(sql)可讀性高也更簡潔
			rs.moveToInsertRow();
			rs.updateInt("empno", 1100);
			rs.updateString("ename", "David");
			rs.updateString("job", "part time");
			Calendar calendar = new GregorianCalendar(2020, 0, 20);
			Date date = new Date(calendar.getTimeInMillis());
			rs.updateDate("hiredate", date);
			rs.updateLong("salary", 10000);
			rs.updateInt("commission", 0);
			rs.updateInt("deptno", 30);
			rs.insertRow();
			rs.moveToCurrentRow();
			
			System.out.println("finished");
			
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		
	
		
		

	}

}
