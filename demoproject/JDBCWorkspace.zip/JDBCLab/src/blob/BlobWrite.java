package blob;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.*;

public class BlobWrite {

	public static void main(String[] args) {
		try (Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/xepdb1", "scott",
				"tiger");) {
			//以preparedStatement作為填入檔案的起手;
			PreparedStatement pstmt = connection.prepareStatement("insert into files(filename,data) values(?,?)");
			Statement stmt = connection.createStatement();
			stmt.execute("delete from files"); //先清空table
			
			File file = new File("C:\\Users\\Student\\Desktop/pan.jpg"); //建立一個檔案
			FileInputStream fis = new FileInputStream(file); //檔案寫入器
			
			pstmt.setString(1, file.getName()); //利用 file.getname取得外部檔案之檔名
			pstmt.setBinaryStream(2, fis); //利用binaryStream設定blob欄位，並用fis寫入檔案 ; 
			pstmt.execute();
			System.out.println("finished");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
