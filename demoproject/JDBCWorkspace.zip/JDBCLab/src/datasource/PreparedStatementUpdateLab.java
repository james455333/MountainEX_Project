package datasource;

import java.io.File;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.sql.*;
import java.util.function.IntPredicate;

import org.apache.commons.dbcp2.BasicDataSource;
import org.omg.CORBA.StructMember;

import oracle.jdbc.AdditionalDatabaseMetaData;

public class PreparedStatementUpdateLab {
	public static void main(String[] args) {
		
		BasicDataSource ds = new BasicDataSource();
		ds.setDriverClassName("oracle.jdbc.OracleDriver");
		ds.setUrl("jdbc:oracle:thin:@//localhost:1521/xepdb1");
		ds.setUsername("scott");
		ds.setPassword("tiger");
		ds.setMaxTotal(50); //設定pool中本connection最大數
		ds.setMaxIdle(50); // connection 處於idle狀態的個數
		
		try ( Connection connection = ds.getConnection();	
				File file = new File("C://java//test1.jpg");
				FileInputStream fis
				) {
			try {
				Statement stmt = connection.createStatement();
				ResultSet rs = stmt.executeQuery("select * from emp, dept where emp.deptno=dept.deptno");
				PreparedStatement prepareStatement = connection.prepareStatement("update emp set commission=? where empno=?");
				
				BigDecimal oneHudred = new BigDecimal(100);
				
				while (rs.next()) {
					String location = rs.getString("location");
					connection.setAutoCommit(false);
					if (location.equals("新竹")) {
						int empno = rs.getInt("empno");
						BigDecimal commission = rs.getBigDecimal("commission");
//					BigDecimal newCommission = commission.add(new BigDecimal(100));
						//流程簡化
						commission = commission.add(oneHudred);
						prepareStatement.setBigDecimal(1, commission);
						prepareStatement.setInt(2, empno);
//					prepareStatement.executeUpdate();
					}
				}
				prepareStatement.addBatch();
				prepareStatement.clearParameters();
				
				connection.commit(); //會全部commit
				
			} catch (SQLException e) {
				connection.rollback();
			} catch (Exception e1) {
				connection.rollback();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
