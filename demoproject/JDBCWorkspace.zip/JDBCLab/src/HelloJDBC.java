import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class HelloJDBC {

	public static void main(String[] args)  {
		//1521為預設port，為預設值時可寫可不寫
		//Connection,Statement,ResultSet都是連線至資料庫的命令，結束需要關閉
		try(
			Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/xepdb1", "scott", "tiger");
			Statement stmt = connection.createStatement();//取得表格
			ResultSet rs = stmt.executeQuery("select * from emp");) {
			
			while( rs.next() ) {
			    String name = rs.getString("ename");
			    //getString() 在大部分情況下都可以使用，但為了維護資料型態正確性，還是盡量使用該欄位本來的資料型態來呼叫
			    int empno = rs.getInt("empno"); // String empno = rs.getString("empno"); 也可以執行，但呼叫出來的會是String型態
			    System.out.println("empno : " + empno + " , " +"ename : " + name );
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		//先開後關
		
		

	}

}
