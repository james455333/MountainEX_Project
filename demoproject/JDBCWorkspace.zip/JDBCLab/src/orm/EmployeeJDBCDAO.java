package orm;

import java.math.BigDecimal;
import java.security.spec.DSAGenParameterSpec;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;

public class EmployeeJDBCDAO implements EmployeeDAO {
	
	private DataSource datasoure;
	
	
	
	public DataSource getDatasoure() {
		//lazy init; 不得不用才去產生(延遲產生物件時間，只到需要時)
		if (datasoure == null) {
			BasicDataSource ds = new BasicDataSource();
			ds.setDriverClassName("oracle.jdbc.OracleDriver");
			ds.setUrl("jdbc:oracle:thin:@//localhost:1521/xepdb1");
			ds.setUsername("scott");
			ds.setPassword("tiger");
			ds.setMaxTotal(50); //設定最多connection上線,超過使用量必須等待
			ds.setMaxIdle(50);   //設定最多idle的connection,超過的connection會被執行connection.close()
			datasoure = ds; //把BasicDataSource放在屬性上
		}
		return datasoure;
	}

	//用於取得所有emp table的資料，轉換成employee物件，因為有多筆，所以回傳為List
	@Override
	public List<Employee> listEmployees(){

		List<Employee> list = new ArrayList<Employee>();

        try (Connection conn = getDatasoure().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("select * from emp ");
             PreparedStatement pstmt = conn.prepareStatement("update emp set commission=? where empno=?")
        ) {
        	while ( rs.next() ) {
        		//每次查詢創造一個emp物件
        		Employee emp = new Employee();
        		//每次查詢用getXXX為其setXXX
				emp.setName(rs.getString("ename"));
				emp.setEmpNO(rs.getInt("empno"));
				emp.setJob(rs.getString("job"));
				emp.setHiredate(rs.getDate("hiredate"));
				emp.setSalary(rs.getBigDecimal("salary"));
				emp.setCommission(rs.getBigDecimal("commission"));
				list.add(emp);
				
			}
        	
        	
        } catch (SQLException e) {
            e.printStackTrace();
        }
		return list;
	}
	
	//更新Employee物件回資料庫
	@Override
	public void updateEmployee(Employee employee) {
		try (Connection conn = getDatasoure().getConnection();
	             PreparedStatement stmt = conn.prepareStatement("update emp set commission=?,hiredate=?,job=?,ename=?,salary=? where empno=?")
	        ) {
	            stmt.setBigDecimal(1, employee.getCommission());
	            //將java.util.Date轉換成java.sql.Date
	            java.sql.Date hireDate = new Date(employee.getHiredate().getTime());
	            stmt.setDate(2, hireDate);
	            stmt.setString(3, employee.getJob());
	            stmt.setString(4, employee.getName());
	            stmt.setBigDecimal(5, employee.getSalary());
	            stmt.setInt(6, employee.getEmpNO());
	            int result = stmt.executeUpdate();
	            if (result == 0) {
	                throw new RuntimeException("update fail");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	            throw new RuntimeException(e);
	        }
		
	}

}
