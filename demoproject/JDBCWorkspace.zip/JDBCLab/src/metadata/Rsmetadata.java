package metadata;

import java.sql.*;

public class Rsmetadata {
	public static void main(String[] args) {
		try (Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/xepdb1", "scott",
				"tiger");) {
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery("select * from emp1");

			ResultSetMetaData rsmd = rs.getMetaData();
			for (int i = 1; i <= rsmd.getColumnCount(); i++) {
				String columnName = rsmd.getColumnName(i);
				String columnTypeName = rsmd.getColumnTypeName(i);
				int columnDisplaySize = rsmd.getColumnDisplaySize(i);
				System.out.print("columnName : " + columnName + "\t"+ "columnTypeName : " + columnTypeName + "\t"+"columnDisplaySize : " + columnDisplaySize);
				int nullable = rsmd.isNullable(i);
				if (nullable == ResultSetMetaData.columnNullable) {
					System.out.println("\t NULL");
				}
				if (nullable == ResultSetMetaData.columnNoNulls) {
					System.out.println("\t NOTNULL");
				}
				if (nullable == ResultSetMetaData.columnNullableUnknown) {
					System.out.println("\t UNknowen");
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			System.out.println("ERROR CODE " + e.getErrorCode());
			System.out.println(e.getSQLState());
		}
		
	}

}
