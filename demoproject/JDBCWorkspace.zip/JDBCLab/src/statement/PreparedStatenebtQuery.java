package statement;

import java.sql.*;

public class PreparedStatenebtQuery {

	public static void main(String[] args) {
		
		try (Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/xepdb1", "scott",
				"tiger");
				) {
			
			//preparedstatement通常用於"重複執行"
			
			
			//oracle的資料庫會先將此compile
			PreparedStatement pstmt = connection.prepareStatement("select * from emp where empno=?");
			pstmt.setInt(1, 1002); //設定第一個問號為1001
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				System.out.println("ename : " + rs.getString("ename") + "\tSalary : " + rs.getInt("salary"));
			}
			pstmt.clearParameters();
			pstmt.setInt(1, 1003);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				System.out.println("ename : " +rs.getString("ename")+ "\tSalary : " + rs.getInt("salary"));
			}
			
			
			
			
			

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
		
		
		
	}

}
