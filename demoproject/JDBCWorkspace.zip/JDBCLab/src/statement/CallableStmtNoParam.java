package statement;

import java.sql.*;

public class CallableStmtNoParam {
	public static void main(String[] args) {
		try (Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/xepdb1", "scott",
				"tiger");) {
			CallableStatement cstmt = connection.prepareCall("{ call queryemployee }");
			cstmt.execute();
			boolean moreResults = cstmt.getMoreResults();//多筆資料回傳認證,在oracle中需要使用 其他db不一定需要
			System.out.println(moreResults);
			if (moreResults) {
				ResultSet rs = cstmt.getResultSet();
				while (rs.next()) {
					System.out.println(rs.getInt("empno") + "," + rs.getString("ename"));
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
