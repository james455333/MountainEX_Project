package statement;

import java.math.BigDecimal;
import java.sql.*;

import org.omg.CORBA.StructMember;

import oracle.jdbc.AdditionalDatabaseMetaData;

public class PreparedStatementUpdateLab {
	public static void main(String[] args) {
		try (Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/xepdb1", "scott","tiger");
				) {
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery("select * from emp, dept where emp.deptno=dept.deptno");
			PreparedStatement prepareStatement = connection.prepareStatement("update emp set commission=? where empno=?");
			
			BigDecimal oneHudred = new BigDecimal(100);
			
			while (rs.next()) {
				String location = rs.getString("location");
				if (location.equals("新竹")) {
					int empno = rs.getInt("empno");
					BigDecimal commission = rs.getBigDecimal("commission");
//					BigDecimal newCommission = commission.add(new BigDecimal(100));
					//流程簡化
					commission = commission.add(oneHudred);
					prepareStatement.setBigDecimal(1, commission);
					prepareStatement.setInt(2, empno);
					prepareStatement.executeUpdate();
					prepareStatement.clearParameters();
					System.out.println("empno : " + empno + " add Commission ");
				}
				
			}
			

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
