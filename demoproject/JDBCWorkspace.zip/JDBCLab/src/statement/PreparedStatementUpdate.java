package statement;

import java.math.BigDecimal;
import java.sql.*;

public class PreparedStatementUpdate {

	public static void main(String[] args) {
		
		try (Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/xepdb1", "scott",
				"tiger");) {
			
			PreparedStatement pstmt = connection.prepareStatement("update emp set salary=? where empno=?");
			BigDecimal salary = new BigDecimal("22500");
			BigDecimal newSalary = salary.divide(new BigDecimal("3"),10,BigDecimal.ROUND_CEILING);
			System.out.println(newSalary);
			pstmt.setBigDecimal(1, salary);
			pstmt.setInt(2, 1002);
			pstmt.executeUpdate();
			
			pstmt.clearParameters();
			//若沒有清除?的值，會造成延續上筆的值
			//且若有設定clearParameters() 只要有值沒有設定就會回報exception
			
			
			
//			pstmt.setBigDecimal(1, new BigDecimal("15000"));
			pstmt.setInt(2, 1003);
			pstmt.executeUpdate();
			
			
			System.out.println("finished");
			

		} catch (SQLException e) {
			e.printStackTrace();
		}
		

	}

}
