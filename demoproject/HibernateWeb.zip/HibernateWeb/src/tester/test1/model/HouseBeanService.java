package tester.test1.model;

import java.util.List;

import org.hibernate.Session;

public class HouseBeanService implements IHouseBeanService {
	
	private static Session session;
	private HouseBeanDAO hBeanDAO;
	
	public HouseBeanService(Session session) {
		hBeanDAO = new HouseBeanDAO(session);
	}
	
	@Override
	public HouseBean insert(HouseBean hBean) {
		return hBeanDAO.insert(hBean);
	}

	@Override
	public HouseBean select(int houseId) {

		return hBeanDAO.select(houseId);
	}

	@Override
	public List<HouseBean> selectAll() {

		return hBeanDAO.selectAll();
	}

	@Override
	public HouseBean updeate(int houseId, String housename) {

		return hBeanDAO.updeate(houseId, housename);
	}

	@Override
	public boolean delete(int houseid) {

		return hBeanDAO.delete(houseid);
	}

}
