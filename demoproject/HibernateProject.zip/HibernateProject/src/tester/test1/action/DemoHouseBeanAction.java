package tester.test1.action;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.RollbackException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.NativeQuery;

import tester.test1.model.HouseBean;

public class DemoHouseBeanAction {

	public static void main(String[] args) {
		
		//
		StandardServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().configure().build();
		SessionFactory factory = new MetadataSources(serviceRegistry).buildMetadata().buildSessionFactory();
		
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		
		
		HouseBean houseBean = new HouseBean();
//		houseBean.setHouseid(1002);
		houseBean.setHousename("The Empror");
		
//		session.save(houseBean);
//		session.delete(houseBean);
		transaction.commit();
		
		
		session.close();
		factory.close();
	}

}
