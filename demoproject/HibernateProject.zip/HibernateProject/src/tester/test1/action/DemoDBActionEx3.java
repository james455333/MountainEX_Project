package tester.test1.action;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import oracle.net.aso.h;
import tester.test1.model.HouseBean;
import tester.test1.model.HouseBeanDAO;
import tester.test1.model.HouseBeanService;
import tester.test1.util.HibernateUtil;

public class DemoDBActionEx3 {

	public static void main(String[] args) {
		
		SessionFactory factory = HibernateUtil.getSessionFactory();
		
		Session session = factory.getCurrentSession();
		try {
			session.beginTransaction();
			
			HouseBeanService houseBeanService = new HouseBeanService(session);
			HouseBean select = houseBeanService.select(1006);
			System.out.println(select.getHouseid() +  " : " + select.getHousename());
			session.getTransaction().commit();
			
		} catch (Exception e) {
			session.getTransaction().rollback();
			e.printStackTrace();
		} 
		
		

		
		
		HibernateUtil.closeSessionFactory();
	}
}
