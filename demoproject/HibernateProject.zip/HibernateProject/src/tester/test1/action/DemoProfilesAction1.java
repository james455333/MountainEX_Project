package tester.test1.action;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.NativeQuery;
import org.hibernate.query.Query;

import tester.test1.model.Department;
import tester.test1.util.HibernateUtil;

public class DemoProfilesAction1 {
	public static void main(String[] args) {
		
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.getCurrentSession();
		
		try {
			
			session.beginTransaction();
			
			Query<Department> query = session.createQuery("From Department", Department.class);
			
			List<Department> list = query.list();
			
			for (Department department : list) {
				System.out.println("id : " + department.getDeptid() + "\tname : " + department.getDeptname() );
			}
			
			Query<Department> query2 = session.createQuery("From Department where Deptname like '%A%'", Department.class);
			
			Department dept1 = query2.uniqueResult();
			
			if (dept1 != null) {
				System.out.println( "id :\t" + dept1.getDeptid() + "\tname :\t" + dept1.getDeptname());
			}else {
				System.out.println("no such result");
			}
			
			
			
			
			session.getTransaction().commit();
		} catch (Exception e) {
			session.getTransaction().rollback();
			
		}
		
		
		
		
		HibernateUtil.closeSessionFactory();
	}
}
