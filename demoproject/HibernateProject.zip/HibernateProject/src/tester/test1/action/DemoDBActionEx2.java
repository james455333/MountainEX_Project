package tester.test1.action;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import oracle.net.aso.h;
import tester.test1.model.HouseBean;
import tester.test1.model.HouseBeanDAO;
import tester.test1.util.HibernateUtil;

public class DemoDBActionEx2 {

	public static void main(String[] args) {
		
		SessionFactory factory = HibernateUtil.getSessionFactory();
		
		Session session = factory.getCurrentSession();
		try {
			session.beginTransaction();
			
			HouseBeanDAO houseBeanDAO = new HouseBeanDAO(session);
			
			List<HouseBean> beforeAction = houseBeanDAO.selectAll();
			System.out.println("Before insert");
			for (HouseBean houseBean : beforeAction) {
				System.out.println("id : " + houseBean.getHouseid() + "\tname : " + houseBean.getHousename());
			}
			
			houseBeanDAO.insert(new HouseBean(1007,"LightHouse"));

			List<HouseBean> afterAction = houseBeanDAO.selectAll();
			System.out.println("after insert");
			Iterator<HouseBean> it1 = afterAction.iterator();
			while (it1.hasNext()) {
				HouseBean next = it1.next();
				System.out.println("id : " + next.getHouseid() + "\tname : " + next.getHousename());
			}
			
			session.getTransaction().commit();
			
		} catch (Exception e) {
			session.getTransaction().rollback();
			e.printStackTrace();
		} 
		
		

		
		
		HibernateUtil.closeSessionFactory();
	}
}
