package tester.test1.action;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.RollbackException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.NativeQuery;

import tester.test1.model.HouseBean;
import tester.test1.util.HibernateUtil;

public class DemoHouseBeanAction4 {

	public static void main(String[] args) {
		
		//
		SessionFactory factory = HibernateUtil.getSessionFactory();

		Session session = factory.getCurrentSession();
		
		try {
			Transaction transaction = session.beginTransaction();

			
			HouseBean houseBean = new HouseBean();
			houseBean.setHouseid(1006);
			houseBean.setHousename("The Worrior");		
			session.save(houseBean);
			
//		session.delete(houseBean);
			
			
			transaction.commit();
			
			
		} catch (Exception e) {
			session.beginTransaction().rollback();
			e.printStackTrace();
			
		} finally {
			//session.close();
			System.out.println("Session has been closed");
			HibernateUtil.closeSessionFactory();
		}
		
		
	}

}
