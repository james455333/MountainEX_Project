package tester.test1.action;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.NativeQuery;
import org.hibernate.query.Query;

import tester.test1.model.Department;
import tester.test1.model.ProfilesBean;
import tester.test1.util.HibernateUtil;

public class DemoDepartmentAction1 {
	public static void main(String[] args) {
		
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.getCurrentSession();
		
		try {
			
			session.beginTransaction();
			
			
			Query<ProfilesBean> query2 = session.createQuery("From ProfilesBean where username =:user and userpwd =:pwd", ProfilesBean.class);
			
			query2.setParameter("user", "Mario");
			query2.setParameter("pwd", "558");
			
			ProfilesBean pro1 = query2.uniqueResult();
			
			if (pro1 != null) {
				System.out.println("user\t" + pro1.getUsername() + "\tlogin success");
			}else {
				System.out.println("username or pwd incorrect");
			}
			
			
			
			
			session.getTransaction().commit();
		} catch (Exception e) {
			session.getTransaction().rollback();
			e.printStackTrace();
		}
		
		
		
		
		HibernateUtil.closeSessionFactory();
	}
}
