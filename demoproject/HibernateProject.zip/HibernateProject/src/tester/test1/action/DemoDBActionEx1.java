package tester.test1.action;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import oracle.net.aso.h;
import tester.test1.model.HouseBean;
import tester.test1.util.HibernateUtil;

public class DemoDBActionEx1 {
	
	private static Session session;
	
	public void processGetAction(int ID) {
		HouseBean hBean1 = session.get(HouseBean.class, ID);
		if (hBean1 != null) {
			System.out.println("\n"+hBean1.getHouseid() + " : "  + hBean1.getHousename());
		}else {
			System.out.println("NO Data was Found");
		}
	}
	
	public void processLoadAction(int ID) {
		try {
			HouseBean hBean1 = session.load(HouseBean.class, ID);
			System.out.println("\n"+hBean1.getHouseid() + " : "  + hBean1.getHousename());
		} catch (Exception e) {
			System.out.println("NO Data was Found2 : " + e.getMessage());
		}
	}

	
	public void processQueryAll() {
		
		Query<HouseBean> query = session.createQuery("From HouseBean",HouseBean.class);
		
		List<HouseBean> hBeans = query.list();
		
		for (HouseBean houseBean : hBeans) {
			System.out.println("id  : " + houseBean.getHouseid() + "\tname  : " +  houseBean.getHousename());
			System.out.println();
		}
		
	}
	
	public void processDelete(HouseBean hBean) {
	
		session.delete(hBean);
		
	}
	

	public static void main(String[] args) {
		
		SessionFactory factory = HibernateUtil.getSessionFactory();
		
		session = factory.getCurrentSession();
		session.beginTransaction();
		
//		new DemoDBActionEx1().processGetAction(1004);
//		new DemoDBActionEx1().processLoadAction(1010);
		new DemoDBActionEx1().processDelete(new HouseBean(1005));
		HouseBean houseBean = new HouseBean(1004, "testHouse");
		session.save(houseBean);
		
		
//		new DemoDBActionEx1().processQueryAll();
		
		session.getTransaction().commit();
		HibernateUtil.closeSessionFactory();
	}
}
