package tester.test1.action;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import tester.test1.model.Books;
import tester.test1.model.BooksDetail;
import tester.test1.util.HibernateUtil;

public class DemoOnetoOneMappingAction1 {

	public static void main(String[] args) {
		
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.getCurrentSession();
		
		try {
			session.beginTransaction();
			
			Books books = new Books();
			books.setName("Harry Potter");
			books.setAuthor("J.K. Rowling");
			books.setPrice(450);
			
			BooksDetail booksDetail = new BooksDetail();
			booksDetail.setPublisher("Bloomsbury");
			booksDetail.setPublisheraddress("UK");
			
			booksDetail.setBooks(books);
			books.setBooksDetail(booksDetail);
			
			session.save(books);
			
			session.getTransaction().commit();
		} catch (Exception e) {
			session.getTransaction().rollback();
		}
		
		HibernateUtil.closeSessionFactory();
		
	}
	
}
