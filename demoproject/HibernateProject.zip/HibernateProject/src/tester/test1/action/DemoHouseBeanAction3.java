package tester.test1.action;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.RollbackException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.NativeQuery;

import tester.test1.model.HouseBean;
import tester.test1.util.HibernateUtil;

public class DemoHouseBeanAction3 {

	public static void main(String[] args) {
		
		//
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.getCurrentSession();
		Transaction transaction = session.beginTransaction();
		
		HouseBean houseBean = new HouseBean();
		houseBean.setHouseid(1005);
		houseBean.setHousename("The Knight");		
		session.save(houseBean);
//		session.delete(houseBean);
		
		transaction.commit();
		
		HibernateUtil.closeSessionFactory();
		
	}

}
