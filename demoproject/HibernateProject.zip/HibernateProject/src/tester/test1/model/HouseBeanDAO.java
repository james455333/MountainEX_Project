package tester.test1.model;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;

public class HouseBeanDAO {
	private Session session;

	public HouseBeanDAO(Session session) {
		this.session = session;
	}

	public HouseBean insert(HouseBean hBean) {

		HouseBean result = session.get(HouseBean.class, hBean.getHouseid());

		if (result == null) {
			session.save(hBean);
			return hBean;
		}
		return null;
	}

	public HouseBean select(int houseId) {
		return session.get(HouseBean.class, houseId);
	}

	public List<HouseBean> selectAll() {

		Query<HouseBean> query = session.createQuery("From HouseBean", HouseBean.class);

		List<HouseBean> hBeans = query.list();

		return hBeans;
	}
	
	public boolean delete(int houseid) {
		HouseBean result = session.get(HouseBean.class, houseid );
		if (result != null) {
			session.delete(result);
			return true;
		}
		return false;
	}
	
	public HouseBean updeate(int houseId, String housename) {
		HouseBean result = session.get(HouseBean.class, houseId);
		if (result != null) {
			result.setHousename(housename);;
		}
		return result;
	}
	
}
