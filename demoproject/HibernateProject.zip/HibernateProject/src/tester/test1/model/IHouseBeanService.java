package tester.test1.model;

import java.util.List;

public interface IHouseBeanService {
	
	public HouseBean insert(HouseBean hBean);
	public HouseBean select(int houseId) ;
	public List<HouseBean> selectAll();
	public HouseBean updeate(int houseId, String housename);
	public boolean delete(int houseid);

}
