package mod10;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mod08.model.CustomerBean;
import mod08.service.Mod08Service;

@WebServlet("/abc/xyz")
public class CreateAttributeObjectServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public CreateAttributeObjectServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Mod08Service service = new Mod08Service();
		
		List<CustomerBean> list = service.getListofJavaBean();
		
		CustomerBean[] array = service.getArrayofJavaBean();
		
		Map<String, CustomerBean> map = service.getMapofJavaBean();
		
		String case01 = service.getSingleString();
		CustomerBean case02 = service.getJavaBean();
		
		request.setAttribute("ListToken", list);
		request.setAttribute("ArrayToken", array);
		request.setAttribute("MapToken", map);
		
		
		
		RequestDispatcher rd = request.getRequestDispatcher("/mod10\\ShowAttributeObeject02.jsp");
		rd.forward(request, response);
		
		return;
	}

	

}
