package mod08.service;

import java.nio.channels.NonWritableChannelException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


import mod08.model.CustomerBean;

public class Mod08Service {

	public String getSingleString() {
		return "快樂學MVC";
	}

	public CustomerBean getJavaBean() {
		CustomerBean kittyBean = null;
		String time0 = "1980-01-01 00:00:00 000";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss SSS");
		try {
			Date date1 = sdf.parse(time0);
			kittyBean = new CustomerBean(1001, "kitty", 2500, date1);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return kittyBean;
	}
	
	public java.util.List<CustomerBean> getListofJavaBean() {
		CustomerBean kitty = null;
		CustomerBean mickey = null;
		CustomerBean snoopy = null;
		java.util.List<CustomerBean> list = new ArrayList<CustomerBean>();
		try {
			String time0 = "1980-01-01 00:00:00 000";
			String time1 = "1980-01-02 00:00:00 000";
			String time2 = "1980-11-03 00:00:00 000";
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss SSS");
			Date date1 = sdf.parse(time0);
			Date date2 = sdf.parse(time1);
			Date date3 = sdf.parse(time2);
			
			kitty = new CustomerBean(1001, "kitty-Array", 2500, date1);
			mickey = new CustomerBean(7788, "mickey-Array", 1500, date2);
			snoopy = new CustomerBean(5566, "snoopy-Array", 3500, date3);
			list.add(kitty);
			list.add(mickey);
			list.add(snoopy);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return list;
	}
	public CustomerBean[] getArrayofJavaBean() {
		CustomerBean kitty = null;
		CustomerBean mickey = null;
		CustomerBean snoopy = null;
		CustomerBean[] ar =null;
		try {
			String time0 = "1980-01-01 00:00:00 000";
			String time1 = "1980-01-02 00:00:00 000";
			String time2 = "1980-11-03 00:00:00 000";
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss SSS");
			Date date1 = sdf.parse(time0);
			Date date2 = sdf.parse(time1);
			Date date3 = sdf.parse(time2);
			
			kitty = new CustomerBean(1001, "kitty-Array", 2500, date1);
			mickey = new CustomerBean(7788, "mickey-Array", 1500, date2);
			snoopy = new CustomerBean(5566, "snoopy-Array", 3500, date3);
			ar = new CustomerBean[] {kitty,mickey,snoopy};
		
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return ar;
	}
	public Map<String, CustomerBean> getMapofJavaBean() {
		CustomerBean kitty = null;
		CustomerBean mickey = null;
		CustomerBean snoopy = null;
		Map<String, CustomerBean> map = new HashMap<String, CustomerBean>();
		try {
			String time0 = "1980-01-01 00:00:00 000";
			String time1 = "1980-01-02 00:00:00 000";
			String time2 = "1980-11-03 00:00:00 000";
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss SSS");
			Date date1 = sdf.parse(time0);
			Date date2 = sdf.parse(time1);
			Date date3 = sdf.parse(time2);
			
			kitty = new CustomerBean(1001, "kitty-Map", 2500, date1);
			mickey = new CustomerBean(7788, "mickey-Map", 1500, date2);
			snoopy = new CustomerBean(5566, "snoopy-Map", 3500, date3);
			
			map.put("kitty_key", kitty);
			map.put("mickey_key", mickey);
			map.put("snoopy_key", snoopy);
			
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return map;
	}
	
	
//	public static void main(String[] args) {
//		Mod08Service mod08Service = new Mod08Service();
//		CustomerBean bean = mod08Service.getJavaBean();
//		System.out.println(bean.toString());
//	}
	
	
	
	
	
	
	

}
