package mod08;

public class ToHexString {
	
	public static void main(String[] args) {
		
		
		char ch1 = '\r';
		char ch2 = '\n';
		
		System.out.println("ch1 = " + ch1 + "\n" + "ch2 = " + ch2);
		System.out.println(Integer.toHexString(ch1));
		System.out.println(Integer.toHexString(ch2));
		
		
		
	}

}
