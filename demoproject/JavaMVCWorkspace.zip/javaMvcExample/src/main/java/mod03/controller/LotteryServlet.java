package mod03.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mod03.model.LotteryBean;
import mod03.service.LotteryService;

@WebServlet("/mod03/LotteryServlet")
public class LotteryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  try {
	          request.setCharacterEncoding("UTF-8");			// 說明傳送到本程式之資料的內碼
	          String name = request.getParameter("visitor"); 	//讀取瀏覽器送來的資料("visitor")
	          if (name == null || name.trim().length() == 0 ) {
	             name = "訪客";   								// 如果讀不到使用者輸入的資料，將變數name設為"訪客"; 
	          }
	          LotteryService service = new LotteryService();	// LotteryBean負責程式的邏輯運算
	          service.setLowerBound(1);                     	// 設定LotteryBean所需的必要參數
	          service.setUpperBound(49);
	          service.setBallNumber(6);
	          LotteryBean bean = service.getLuckyNumbers();		// 請LotteryBean產生所需的結果
	          request.setAttribute("visitName", name);			// 將第一項資訊放入request物件內
	          request.setAttribute("luckyNumber", bean);		// 將第二項資訊放入request物件內
	          RequestDispatcher rd =                       		// 準備將移轉程式的執行順序
	                 request.getRequestDispatcher("/mod03/goodLuck.jsp");
	          rd.forward(request, response);               		// 移轉程式的執行順序
	          return ;                                     		// forward()之後會有一個return敘述
	       } catch(UnsupportedEncodingException e) {
	          throw new ServletException(e); 
	       }

	}

}
