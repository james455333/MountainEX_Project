﻿package mod10.service;

import java.util.List;

import mod00.MemberBean;
import mod10.dao.MemberDao;

public class MemberService {
	MemberDao dao;
	
	public MemberService() throws Exception {
		this.dao = new MemberDao();
	}

	public List<MemberBean> getMembers() throws Exception{
		return dao.getAllMembers();
	}
}