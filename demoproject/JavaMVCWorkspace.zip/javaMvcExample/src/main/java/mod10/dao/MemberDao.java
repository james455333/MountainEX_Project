package mod10.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import mod00.MemberBean;
import mod00.SystemConfiguration;

public class MemberDao {
	String jndi = SystemConfiguration.getJndiLookup();
	Context ctx;
	String jndiLookup = SystemConfiguration.getJndiLookup();

	public MemberDao() throws Exception {
		ctx = new InitialContext();
	}

	public List<MemberBean> getAllMembers() throws Exception {

		DataSource ds = (DataSource) ctx.lookup(jndiLookup);
		List<MemberBean> allMembers = new ArrayList<>();
		try (
			Connection conn = ds.getConnection();
			PreparedStatement stmt = conn.prepareStatement("SELECT * from  MVCMember");
			ResultSet rs = stmt.executeQuery();
		) {
			while (rs.next()) {
				MemberBean mem = new MemberBean(rs.getInt("pk"), rs.getString("account"), 
						rs.getString("name"), rs.getString("password"), rs.getString("phone"), 
						rs.getDate("birthday"), rs.getTimestamp("registerDate"), rs.getDouble("weight"));
				allMembers.add(mem);
			}
		}
		return allMembers;
	}
}
