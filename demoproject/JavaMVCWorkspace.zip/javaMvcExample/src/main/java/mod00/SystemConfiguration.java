package mod00;

public class SystemConfiguration {

	public final static int RECORDS_PER_PAGE = 3;
	
	private final static String VERSION = "195"; 
	private final static String MYSQL = "M"; 
	private final static String SQLSERVER = "S";
	private final static String ORACLE = "O";
	private final static String dbType = ORACLE;
	// --------------------------------------
	private final static String mssql = "java:comp/env/jdbc/MemberDataBaseS";
	private final static String mysql = "java:comp/env/jdbc/MemberDataBaseM";
	private final static String orasql = "java:comp/env/jdbc/MemberDataBaseO";
	
	
	public String getVersion() {
		return dbType + VERSION;
	}
	
	static public String getJndiLookup() {
		if (dbType.startsWith("M")) {
			return mysql;
		} else if (dbType.startsWith("S")) {
			return mssql;
		} else {
			return orasql;
		}
	}
	
	
}
