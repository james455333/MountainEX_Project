package mod02.service;

import java.text.SimpleDateFormat;
import java.util.TimeZone;

public class TimeReportService {
	TimeZone timeZone;
	String pattern = "yyyy年MM月dd日 HH時mm分ss秒 SSS毫秒";

	public TimeZone getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(TimeZone timeZone) {
		this.timeZone = timeZone;
	}
	public String getTime(){
		SimpleDateFormat  sdf = new SimpleDateFormat(pattern);
		sdf.setTimeZone(timeZone);
		return sdf.format(new java.util.Date());
	}
	
}
