package mod07a.controller;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mod00.MemberBean;
import mod07a.service.MemberFileService;

@WebServlet("/mod07a/member.do")
public class ProcessMemberServletNG extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 設定輸入資料的編碼
		request.setCharacterEncoding("UTF-8");
		// 準備存放錯誤訊息的 List 物件
		Map<String, String> errorMsg = new HashMap<>();
		request.setAttribute("errorMsg", errorMsg);
		// 讀取使用者所輸入，由瀏覽器送來的 mId 欄位內的資料，注意大小寫
		String id = request.getParameter("mId");
		// 讀取使用者所輸入，由瀏覽器送來的 pswd 欄位內的資料，注意大小寫
		String password = request.getParameter("pswd");
		// 讀取使用者所輸入，由瀏覽器送來的 mName 欄位內的資料
		String name = request.getParameter("mName");
		// 讀取使用者所輸入，由瀏覽器送來的 mPhone 欄位內的資料
		String phone = request.getParameter("mPhone");
		// 讀取使用者所輸入，由瀏覽器送來的 mBirthday 欄位內的資料
		String bday = request.getParameter("mBirthday");
		// 2. 進行必要的資料轉換
		java.sql.Date date = null;
		if (bday != null && bday.trim().length() > 0 ) {
			try {
				date = java.sql.Date.valueOf(bday);
			} catch (Exception e) {
				errorMsg.put("mBirthday", "生日格式錯誤，請重新輸入");
			}
		}
		Timestamp ts = new Timestamp(System.currentTimeMillis());
		String weight = request.getParameter("mWeight");
		double dWeight = 0;

		if (weight != null && weight.trim().length() > 0 ) {
			try {
				dWeight = Double.parseDouble(weight.trim());
			} catch (NumberFormatException e) {
				errorMsg.put("mWeight", "體重格式錯誤，請重新輸入");
			} catch (NullPointerException e) {
				;
			}
		}
		// 3. 檢查使用者輸入資料
		if (id == null || id.trim().length() == 0) {
			errorMsg.put("mId", "帳號欄必須輸入");
		}
		if (password == null || password.trim().length() == 0) {
			errorMsg.put("pswd", "密碼欄必須輸入");
		}
		if (name == null || name.trim().length() == 0) {
			errorMsg.put("mName", "姓名欄必須輸入");
		}
		if (phone == null || phone.trim().length() == 0) {
			errorMsg.put("mPhone", "手機欄必須輸入");
		}

		if (!errorMsg.isEmpty()) {
			RequestDispatcher rd = request.getRequestDispatcher("/mod07a/insertMemberForm.jsp");
			rd.forward(request, response);
			return;
		}
		// MemberBean 扮演封裝輸入資料的角色
		MemberBean mb = new MemberBean(null, id, name, password, phone, date, ts, dWeight);
		try {
			request.setAttribute("memberBean", mb);
			HttpSession session = request.getSession();
			session.setAttribute("memberBeanS", mb);
			MemberFileService service = new MemberFileService("c:\\data\\memberA.dat");
			service.insertMember(mb);
			// 產生 RequestDispatcher 物件 rd
			RequestDispatcher rd = request.getRequestDispatcher("/mod07a/insertMemberSuccess.jsp");
			// 請容器代為呼叫下一棒程式
			rd.forward(request, response);
			return;
		} catch (IOException e) {
			// 產生 RequestDispatcher 物件 rd
//			RequestDispatcher rd = request.getRequestDispatcher("/mod07a/insertMemberForm.jsp");
			// 請容器代為呼叫下一棒程式
//			rd.forward(request, response);
			String contextPath = request.getContextPath();
			response.sendRedirect(contextPath + "/mod07a/insertMemberForm.jsp" );
			
			return;
		}
	}

}
