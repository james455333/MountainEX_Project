﻿package mod07a.service;
 
import java.io.IOException;

import mod00.MemberBean;
import mod07a.dao.MemberFileIO;
 
public class MemberFileService {
	MemberFileIO fio;
	
	public MemberFileService(String  path) {
		this.fio = new MemberFileIO(path);
	}

	public void insertMember(MemberBean mb) throws IOException {
		fio.insertMember(mb);
	}	
	
}