package mod07b.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import mod00.MemberBean;
import mod00.SystemConfiguration;

public class MemberDao {
//	String jndi = SystemConfiguration.getJndiLookup();
	Context ctx;
	String jndiLookup = SystemConfiguration.getJndiLookup();


	public MemberDao() throws Exception {
		ctx = new InitialContext();
		System.out.println(jndiLookup);
	}

	public boolean idExists(String id) throws Exception {
		boolean exist = false;
		String sql = "SELECT * FROM MVCMember WHERE account = ?";
		DataSource ds = (DataSource) ctx.lookup(jndiLookup);
		try (
			Connection conn = ds.getConnection(); 
			PreparedStatement ps = conn.prepareStatement(sql);
		) {
			ps.setString(1, id);
			try (ResultSet rs = ps.executeQuery();) {
				if (rs.next()) {
					exist = true; 
				}
			}
		}
		return exist;
	}

	synchronized public int insertMember(MemberBean bean) throws Exception {
		DataSource ds = (DataSource) ctx.lookup(jndiLookup);
		String sql = "Insert into MVCMember " 
				+ " (account, password, name, phone, birthday, registerDate, weight) "
				+ " values(?, ?, ?, ?, ?, ?, ?)";
		int n = 0;
		try (
			Connection conn = ds.getConnection(); 
			PreparedStatement stmt = conn.prepareStatement(sql);
		) {
			stmt.setString(1, bean.getMemberId());
			stmt.setString(2, bean.getPassword());
			stmt.setString(3, bean.getName());
			stmt.setString(4, bean.getPhone());
			stmt.setDate(5, bean.getBirthday());
			stmt.setTimestamp(6, new Timestamp(System.currentTimeMillis()));
			stmt.setDouble(7, bean.getWeight());
			n = stmt.executeUpdate();
		}
		return n;
	}

	public List<MemberBean> getAllMembers() throws Exception {

		DataSource ds = (DataSource) ctx.lookup(jndiLookup);
		List<MemberBean> allMembers = new ArrayList<>();
		try (
			Connection conn = ds.getConnection();
			PreparedStatement stmt = conn.prepareStatement("SELECT * from  MVCMember");
			ResultSet rs = stmt.executeQuery();
		) {
			while (rs.next()) {
				MemberBean mem = new MemberBean(rs.getInt(1), rs.getString(2), 
						rs.getString(3), rs.getString(4), rs.getString(5), 
						rs.getDate(6), rs.getTimestamp(7), rs.getDouble(8));
				allMembers.add(mem);
			}
		}
		return allMembers;
	}
}
