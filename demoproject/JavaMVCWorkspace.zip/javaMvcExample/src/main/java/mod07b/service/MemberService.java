﻿package mod07b.service;

import mod00.MemberBean;
import mod07b.dao.MemberDao;

public class MemberService {
	MemberDao dao;
	
	public MemberService() throws Exception {
		this.dao = new MemberDao();
	}

	public void insertMember(MemberBean bean) throws Exception{
		dao.insertMember(bean);
	}
	
	public boolean idExists(String id) throws Exception {
		return dao.idExists(id);
	}
}