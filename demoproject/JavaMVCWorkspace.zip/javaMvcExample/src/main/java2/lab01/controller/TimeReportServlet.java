package lab01.controller;

import java.io.IOException;
import java.util.TimeZone;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mod02.service.TimeReportService;

@WebServlet("/lab01/TimeReport")
public class TimeReportServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		TimeZone timezone = null;
		request.setCharacterEncoding("UTF-8"); // 說明傳送到本程式之資料的內碼
		// 讀取瀏覽器送來的資料("city")
		String cityInfo = request.getParameter("city");
		String[] data = cityInfo.split(";");  
		String timezoneCode = data[0]; 
		String cityName = data[1];
		if (timezoneCode == null || timezoneCode.trim().length() == 0) {
			timezone = TimeZone.getDefault();
		} else {
			timezone = TimeZone.getTimeZone(timezoneCode);
		}
		TimeReportService service = new TimeReportService();
		service.setTimeZone(timezone);
		String timeNow = service.getTime();
		request.setAttribute("time", timeNow);
		request.setAttribute("city", cityName);
		
		RequestDispatcher rd = request.getRequestDispatcher("/lab01/ShowTime.jsp");
		rd.forward(request, response);
		return;

	}
}