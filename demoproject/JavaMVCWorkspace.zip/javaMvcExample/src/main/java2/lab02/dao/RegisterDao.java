package lab02.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collection;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import lab02.model.UserBean;
import mod00.SystemConfiguration;

public class RegisterDao {
	Context ctx;
	String jndiLookup = SystemConfiguration.getJndiLookup();

	public RegisterDao() throws Exception {
		ctx = new InitialContext();
	}

	public boolean idExists(String id) throws Exception {
		boolean exist = false;
		String sql = "SELECT * FROM memberExample WHERE account = ?";
		DataSource ds = (DataSource) ctx.lookup(jndiLookup);
		try (
			Connection conn = ds.getConnection(); 
			PreparedStatement ps = conn.prepareStatement(sql);
		) {
			ps.setString(1, id);
			try (ResultSet rs = ps.executeQuery();) {
				if (rs.next()) {
					exist = true;
				}
			}
		}
		return exist;
	}

	synchronized public int saveMember(UserBean mem) throws Exception {
		DataSource ds = (DataSource) ctx.lookup(jndiLookup);
		String sql = "Insert into memberExample " 
				+ " (account, password, name, email, tel, experience) "
				+ " values(?, ?, ?, ?, ?, ?)";
		int n = 0;
		try (
			Connection conn = ds.getConnection(); 
			PreparedStatement stmt = conn.prepareStatement(sql);
		) {
			stmt.setString(1, mem.getUserId());
			stmt.setString(2, mem.getPassword());
			stmt.setString(3, mem.getName());
			stmt.setString(4, mem.getEmail());
			stmt.setString(5, mem.getTel());
//			stmt.setInt(6, mem.getExperience());
			n = stmt.executeUpdate();
		}
		return n;
	}

	public Collection<UserBean> getAllMembers() throws Exception {

		DataSource ds = (DataSource) ctx.lookup(jndiLookup);
		Collection<UserBean> allMembers = new ArrayList<UserBean>();
		try (
			Connection conn = ds.getConnection();
			PreparedStatement stmt = conn.prepareStatement("SELECT * from  memberExample");
			ResultSet rs = stmt.executeQuery();
		) {
			while (rs.next()) {
				UserBean mem = new UserBean(rs.getString(2), rs.getString(3), rs.getString(4), 
						rs.getString(5), rs.getString(6), rs.getInt(7));
				allMembers.add(mem);
			}
		}
		return allMembers;
	}
}
