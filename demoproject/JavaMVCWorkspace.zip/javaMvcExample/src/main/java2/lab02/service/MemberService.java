﻿package lab02.service;

import java.io.IOException;
import java.util.List;

import lab02.dao.MemberDao;
import lab02.model.MemberBean;

public class MemberService {

	MemberDao dao;

	public MemberService() throws IOException {

		try {
			dao = new MemberDao();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	public boolean idExists(String id) throws Exception {
		return dao.idExists(id);
	}

	public int saveMember(MemberBean mem) throws Exception {
		return dao.saveMember(mem);
	}

	public List<MemberBean> getAllMembers() throws Exception {
		return dao.getAllMembers();
	}
}
