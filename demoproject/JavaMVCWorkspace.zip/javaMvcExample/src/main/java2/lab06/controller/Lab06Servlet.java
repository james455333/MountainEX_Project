package lab06.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mod00.Cat;
@WebServlet("/lab06/forEach04")
public class Lab06Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Cat garfield = new Cat(10, "嘉菲(Map)");
		Cat kitty = new Cat(3, "凱蒂(Map)");
		Cat pili = new Cat(3, "霹靂(Map)");
		Map<String, Cat> aMap = new HashMap<String, Cat>();
		aMap.put("Garf_key", garfield);
		aMap.put("Kitt_key", kitty);
		aMap.put("Pili_key", pili);
		request.setAttribute("CatMap", aMap);
		RequestDispatcher rd = request.getRequestDispatcher("/lab06/forEach04.jsp");
		rd.forward(request, response);
		return;
	}
}
