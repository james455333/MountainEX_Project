package lab07.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lab02.model.MemberBean;
import lab02.service.MemberService;

@WebServlet("/lab07/getAllMembers.do")
public class QueryAllMembersServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		try {
			MemberService service = new MemberService();
			List<MemberBean>  members = service.getAllMembers();
			request.setAttribute("allMembers", members);

		} catch(Exception e) {
			e.printStackTrace();
			request.setAttribute("error", e.getMessage());
		}
		RequestDispatcher rd = request.getRequestDispatcher("/lab03/showAllMembers.jsp");
		rd.forward(request, response);
		return;		
		
	}
}
