package lab04.controller;

import java.io.IOException;
import java.sql.Date;
import java.sql.Timestamp;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mod00.MemberBean;

@WebServlet("/lab04/forEach02")
public class Lab04Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		MemberBean m1 = new MemberBean(101, "akt001", "劉忠華", "Do!ng123", "0919-654852", 
				Date.valueOf("1980-5-8"), Timestamp.valueOf("2016-7-14 17:45:30"), 59.5);  
		
		MemberBean m2 = new MemberBean(175, "oty095", "黃美玲", "ppl!o456", "0939-852741", 
				Date.valueOf("1986-7-19"), Timestamp.valueOf("2015-1-7 10:33:27"), 49.0);
		
		MemberBean m3 = new MemberBean(227, "abzpi6", "林小珍", "eeit8857", "0965-123456", 
				Date.valueOf("1987-4-20"), Timestamp.valueOf("2017-9-1 11:05:57"), 49.0);
		MemberBean members[] = {m1, m2, m3};
		request.setAttribute("MemArray", members);
		RequestDispatcher rd = request.getRequestDispatcher("/lab04/forEach02.jsp");
		rd.forward(request, response);
		return;
	}

}
