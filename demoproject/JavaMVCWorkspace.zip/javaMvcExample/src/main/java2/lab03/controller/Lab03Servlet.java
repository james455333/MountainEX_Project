package lab03.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/lab03/forEach01")
public class Lab03Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String  names = "史奴比, 貓凱蒂, 米小奇, 嘉菲貓"; 
		request.setAttribute("cartoon_chars", names);
		RequestDispatcher rd = request.getRequestDispatcher("/lab03/forEach01.jsp");
		rd.forward(request, response);
		return;
	}



}
