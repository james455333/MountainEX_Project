package lab05.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mod00.Cat;

@WebServlet("/lab05/forEach03")
public class Lab05Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Cat garfield       = new Cat(10, "嘉菲(Collection)");
	    Cat kitty          = new Cat(3  , "凱蒂(Collection)");
	    Cat pili           = new Cat(3  ,  "霹靂(Collection)");
	    Collection<Cat> cc = new ArrayList<Cat>();
	    cc.add(garfield);
	    cc.add(kitty);
	    cc.add(pili);
	    request.setAttribute("CatCollection", cc);
		RequestDispatcher rd = request.getRequestDispatcher("/lab05/forEach03.jsp");
		rd.forward(request, response);
		return;
	}

}
