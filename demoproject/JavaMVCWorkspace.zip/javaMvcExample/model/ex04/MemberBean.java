﻿package ex04.model; 

import java.io.Serializable; 
import java.sql.Date;
import java.sql.Timestamp;

public class MemberBean implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer pk;
	private String memberId;   			// 帳號
	private String password;   			// 密碼
	private String name;       			// 姓名
	private String	phone;     			// 電話
	private Date birthday;	// 生日	
	private Timestamp registerDate;	// 會員登錄日期
	private double weight;				// 體重
	
	public MemberBean() {
	} 
	
	public Integer getPk() {
		return pk;
	}

	public void setPk(Integer pk) {
		this.pk = pk;
	}

	public MemberBean(Integer pk, String memberId, String name, String password, String phone, Date birthday,
			Timestamp registerDate, double weight) {
		super();
		this.pk = pk;
		this.memberId = memberId;
		this.name = name;
		this.password = password;
		this.phone = phone;
		this.birthday = birthday;
		this.registerDate = registerDate;
		this.weight = weight;
	}

	public Timestamp getRegisterDate() {
		return registerDate;
	}

	public void setRegisterDate(java.sql.Timestamp registerdate) {
		this.registerDate = registerdate;
	}
	
//	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//
//	public static java.util.Date convertDate(String temp){
//		java.util.Date result = new java.util.Date();
//		try {
//			result=sdf.parse(temp);
//		} catch (ParseException e) {
//			result = null ; 
//			e.printStackTrace();
//		}
//		return result;
//	}
	
	@Override
	public String toString() {
		return "MemberBean [pk=" + pk + ", memberId=" + memberId + ", password=" + password + ", name=" + name
				+ ", phone=" + phone + ", birthday=" + birthday + ", registerDate=" + registerDate + ", weight="
				+ weight + "]";
	}	

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public java.sql.Date getBirthday() {
		return birthday;
	}

	public void setBirthday(java.sql.Date birthday) {
		this.birthday = birthday;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}
}