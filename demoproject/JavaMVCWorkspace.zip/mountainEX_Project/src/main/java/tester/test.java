package tester;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import javax.sql.DataSource;


public class test {
	
	public static void main(String[] args) {
//		DataS dataS = new DataS();
//		
//		DataSource ds = dataS.ds;
		DataS dataS = new DataS();
		dataS.setUsername("demo");
		dataS.setUserPassword("demo");
		DataSource ds = dataS.getDatasoure();
		try(
				Connection connection = ds.getConnection();
				) {
			
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery("select * from route_summary");
			while (rs.next()) {
				
				System.out.println(rs.getString("name"));
				
				
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	

}
