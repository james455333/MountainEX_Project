package test1.action;

import java.util.ArrayList;

import org.hibernate.tool.schema.internal.exec.ScriptTargetOutputToFile;
import org.springframework.expression.Expression;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;

import test1.model.TruckBean;

public class DemoSpELAction {

	public void processAction1() {
		SpelExpressionParser parser = new SpelExpressionParser();

		Expression express = parser.parseExpression("'hola," + "Amigo?'");
		String result = express.getValue().toString();

		System.out.println(result);

	}
	
	public void processAction2() {
		SpelExpressionParser parser = new SpelExpressionParser();
		
		StandardEvaluationContext ectx = new StandardEvaluationContext();
		
		TruckBean truck1 = new TruckBean(2001,"Honda");
		TruckBean truck2 = new TruckBean(2002,"SanYang");
		
		ArrayList<TruckBean> list = new ArrayList<TruckBean>();
		list.add(truck1);
		list.add(truck2);
		
		ectx.setVariable("list", list);
		String brand = parser.parseExpression("#list[1].brand").getValue(ectx,String.class);
	
		System.out.println("brand : " + brand );
	}

	public static void main(String[] args) {
		DemoSpELAction action1 = new DemoSpELAction();
//		action1.processAction1();
		action1.processAction2();
	}

}
