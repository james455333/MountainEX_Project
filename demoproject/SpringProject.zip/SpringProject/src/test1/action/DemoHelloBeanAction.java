package test1.action;

import java.util.HashMap;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import test1.model.HelloBean;
import test1.model.LoginDAO;
import test1.model.LoginService;
import test1.model.TruckBean;

public class DemoHelloBeanAction {
	
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("bean.config.xml");
		
		HelloBean t1 = (HelloBean)context.getBean("helloBean");
		t1.sayHello("Rick Sanchez");
		
		LoginDAO check = (LoginDAO)context.getBean("loginDao1");
		boolean checkLogin = check.checkLogin("morty", "test123");
		System.out.println("status : " + checkLogin);
		if (checkLogin) {
			System.out.println("login successed");
		}else {
			System.out.println("login failed");
		}
		
		LoginService service = (LoginService)context.getBean("loginService3");
		boolean checkLogin2 = service.checkLogin("john", "test124");
		System.out.println("status2 : " + checkLogin2);
		
		if (checkLogin2) {
			System.out.println("login successed");
		}else {
			System.out.println("login failed");
		}
		
		((ConfigurableApplicationContext)context).close();
		
	}
	

}
