package test1.action;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import test1.model.WorkerDAO;

public class DemoWorkerAction {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("bean.config.xml");
		
		WorkerDAO workerDAO=(WorkerDAO) context.getBean("workerDAO1");
		
		workerDAO.printDetails();
		
		
		((ConfigurableApplicationContext)context).close();
	}

}
