package test1.action;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import test1.model.TruckBean;

public class DemoStaticFactoryTruckBeanAction {
	
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("bean.config.xml");
		
		TruckBean t1 = (TruckBean)context.getBean("toyotaTruck");
		System.out.println("ID : " + t1.getId() );
		System.out.println("Brand : " + t1.getBrand());
		TruckBean t2 = (TruckBean)context.getBean("NessanTruck");
		System.out.println("ID : " + t2.getId() );
		System.out.println("Brand : " + t2.getBrand());
		
		
		
		
		((ConfigurableApplicationContext)context).close();
		
	}
	

}
