package test1.action;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import test1.model.TruckBean;

public class DemoTruckBeanAction {
	
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("bean.config.xml");
		
		TruckBean t1 = (TruckBean)context.getBean("truckBean");
		System.out.println("ID : " + t1.getId() );
		System.out.println("Brand : " + t1.getBrand());
		
		((ConfigurableApplicationContext)context).close();
		
	}
	

}
