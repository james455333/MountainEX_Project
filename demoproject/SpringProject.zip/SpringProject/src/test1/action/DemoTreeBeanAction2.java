package test1.action;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import test1.model.TreeBean2;

public class DemoTreeBeanAction2 {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("bean.config.xml");
		
		TreeBean2 treeBean=(TreeBean2)context.getBean("tree");
		System.out.println("name : " + treeBean.getName());
		System.out.println("age : " + treeBean.getAge());
		
		((ConfigurableApplicationContext)context).close();
	}

}
