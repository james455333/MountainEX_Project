package test1.action;

import java.util.HashMap;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import test1.model.TruckBean;

public class DemoTruckBeanFactoryAction2 {
	
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("bean.config.xml");
		
		TruckBean t1 = (TruckBean)context.getBean("bmwTruck");
		System.out.println("id : " + t1.getId() );
		System.out.println("Brand : " + t1.getBrand());
		
		((ConfigurableApplicationContext)context).close();
		
	}
	

}
