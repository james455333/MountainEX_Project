package test1.action;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import test1.model.TestStringConstructorDI;

public class DemoBeanScopeAction {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("bean.config.xml");
		
		
		TestStringConstructorDI msg1 = (TestStringConstructorDI)context.getBean("msg1");
		TestStringConstructorDI msg2 = (TestStringConstructorDI)context.getBean("msg1");
		System.out.println("code1 = " + msg1.hashCode());
		System.out.println("code2 = " + msg2.hashCode());
		
		((ConfigurableApplicationContext)context).close();
	}

}
