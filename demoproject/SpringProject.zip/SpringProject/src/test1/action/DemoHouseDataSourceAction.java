package test1.action;

import java.sql.SQLException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import test1.model.House;
import test1.model.HouseDAO;

public class DemoHouseDataSourceAction {
	
	public static void main(String[] args) throws SQLException {
		
			ApplicationContext context = new ClassPathXmlApplicationContext("bean.config.xml");
			HouseDAO hDAO = (HouseDAO)context.getBean("HouseDAO");
			House hBean1 = hDAO.select(1003);
			System.out.println("id : " + hBean1.getHouseid() + " name : " + hBean1.getHousename());
			House hBean2 = hDAO.select(1006);
			System.out.println("id : " + hBean2.getHouseid() + " name : " + hBean2.getHousename());
			
			((ConfigurableApplicationContext)context).close();
	}

}
