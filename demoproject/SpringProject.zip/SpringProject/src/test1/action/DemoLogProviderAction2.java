package test1.action;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import test1.model.TestStringConstructorDI;
import test1.util.LogProvider;

public class DemoLogProviderAction2 {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("bean.config.xml");

		TestStringConstructorDI test1 = (TestStringConstructorDI)context.getBean("msg1");
		test1.showInfo();
		TestStringConstructorDI test2 = (TestStringConstructorDI)context.getBean("msg2");
		test2.showInfo();
		TestStringConstructorDI test3 = (TestStringConstructorDI)context.getBean("msg3");
		test3.showInfo();
		
		((ConfigurableApplicationContext)context).close();
		
		
		
	}

}
