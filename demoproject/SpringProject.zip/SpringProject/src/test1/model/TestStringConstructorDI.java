package test1.model;

public class TestStringConstructorDI {
	
	private String name;

	public TestStringConstructorDI() {
	}
	
	public TestStringConstructorDI(String name) {
		this.name = name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	public void showInfo() {
		System.out.printf("msg= %s\n", name);
	}
	
	public void init() {
//		System.out.println("initial compeleted;");
	}
	
	public void destroy() {
//		System.out.println("destroy compeleted;");
	}

}
