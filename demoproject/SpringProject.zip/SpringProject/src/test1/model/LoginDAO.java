package test1.model;

import org.springframework.stereotype.Repository;

@Repository("loginDao1")
public class LoginDAO {
	
	public boolean checkLogin(String user, String pwd) {
		if ("john".equals(user) && "test124".equals(pwd)) {
			return true;
		}else {
			return false;
		}
		
	}
	

}
