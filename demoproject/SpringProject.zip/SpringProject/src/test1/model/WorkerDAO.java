package test1.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

@Repository("workerDAO1")
public class WorkerDAO {
	
	// @Autowired
	// @Qualifier("work2")
	private Worker worker;
	
	/*
	 * public WorkerDAO() { // TODO Auto-generated constructor stub }
	 */
	
	@Autowired
	public WorkerDAO(@Qualifier("work2") Worker worker) {
		this.worker = worker;
	}
	
	public void printDetails() {
		
		System.out.println("id :\t" + worker.getId());
		System.out.println("name :\t" + worker.getName());
		System.out.println("title :\t" + worker.getTitle());
		
	}
	
	
}
