package test1.model;

import org.springframework.stereotype.Component;

@Component("helloBean")
public class HelloBean {
	
	private String name;
	
	public HelloBean() {
	}
	
	public void sayHello(String name) {
		
		System.out.println("HI, "+ name);
	
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
