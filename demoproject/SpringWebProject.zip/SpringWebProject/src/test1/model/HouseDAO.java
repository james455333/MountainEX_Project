package test1.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

@Repository("HouseDAO")
public class HouseDAO {
	
	private DataSource dataSource;
	
	@Autowired
	public HouseDAO(@Qualifier("oracledatasource") DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	public House select(int houseid) throws SQLException {
		
		House hBean = null;
		try (
				Connection connection = dataSource.getConnection();
				PreparedStatement pstmt = connection.prepareStatement("select * from house where houseid = ?");
				){
			pstmt.setInt(1, houseid);
			
			ResultSet rs = pstmt.executeQuery();
			
			if (rs.next()) {
				
				hBean = new House();
				
				hBean.setHouseid(rs.getInt("houseid"));
				hBean.setHousename(rs.getString("housename"));
				
			}
			pstmt.clearParameters();
			
		}
		
		return hBean;
		
	}
}
