package test1.model;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

public class HouseBeanDAO {
	private SessionFactory sessionFactory;
//	private Session session;

	public HouseBeanDAO(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
		
	}

	public HouseBean insert(HouseBean hBean) {
		Session session = sessionFactory.getCurrentSession();
		HouseBean result = session.get(HouseBean.class, hBean.getHouseid());

		if (result == null) {
			session.save(hBean);
			return hBean;
		}
		return null;
	}

	public HouseBean select(int houseId) {
		Session session = sessionFactory.getCurrentSession();
		return session.get(HouseBean.class, houseId);
	}

	public List<HouseBean> selectAll() {
		Session session = sessionFactory.getCurrentSession();
		Query<HouseBean> query = session.createQuery("From HouseBean", HouseBean.class);

		List<HouseBean> hBeans = query.list();

		return hBeans;
	}
	
	public boolean delete(int houseid) {
		Session session = sessionFactory.getCurrentSession();
		HouseBean result = session.get(HouseBean.class, houseid );
		if (result != null) {
			session.delete(result);
			return true;
		}
		return false;
	}
	
	public HouseBean updeate(int houseId, String housename) {
		Session session = sessionFactory.getCurrentSession();
		HouseBean result = session.get(HouseBean.class, houseId);
		if (result != null) {
			result.setHousename(housename);;
		}
		return result;
	}
	
}
