package test1.model;

import java.sql.SQLException;

public class HouseService {
	
	private HouseDAO houseDAO ;
	
	public HouseService(HouseDAO houseDAO) {
		this.houseDAO = houseDAO;
	}
	
	public House select(int houseid) throws SQLException {
		
		return houseDAO.select(houseid);
		
	}
	

}
