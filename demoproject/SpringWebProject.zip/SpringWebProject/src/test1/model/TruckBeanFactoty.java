package test1.model;

import java.util.HashMap;

public class TruckBeanFactoty {
	
	private HashMap<Integer, TruckBean> map = new HashMap<Integer, TruckBean>();

	public void setMap(HashMap<Integer, TruckBean> map) {
		this.map = map;
	}
	
	public TruckBean geTruckBean(int id) {
		return map.get(id);
	}
	

}
