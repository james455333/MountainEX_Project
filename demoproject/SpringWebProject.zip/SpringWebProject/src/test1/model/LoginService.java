package test1.model;

import javax.xml.bind.annotation.XmlElementWrapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("loginService3")
public class LoginService {
	@Autowired
	private LoginDAO loginDAO;
	
	public LoginService() {
	}
	
	public LoginService(LoginDAO loginDAO) {
		this.loginDAO = loginDAO;
	}
	
	public void setLoginDAO(LoginDAO loginDAO) {
		this.loginDAO = loginDAO;
	}
	
	public boolean checkLogin(String user, String pwd) {
		return loginDAO.checkLogin(user, pwd);
	}

}
