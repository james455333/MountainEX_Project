package test1.model;

import java.util.List;

import org.hibernate.Session;

public class HouseBeanService {
	
	private HouseBeanDAO hBeanDAO;
	
	public HouseBeanService(HouseBeanDAO hBeanDAO) {
//		hBeanDAO = new HouseBeanDAO(session);
		this.hBeanDAO = hBeanDAO;
	}
	
	public HouseBean insert(HouseBean hBean) {
		return hBeanDAO.insert(hBean);
	}

	public HouseBean select(int houseId) {

		return hBeanDAO.select(houseId);
	}

	public List<HouseBean> selectAll() {

		return hBeanDAO.selectAll();
	}

	public HouseBean updeate(int houseId, String housename) {

		return hBeanDAO.updeate(houseId, housename);
	}

	public boolean delete(int houseid) {

		return hBeanDAO.delete(houseid);
	}

}
