package test1.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import test1.model.House;
import test1.model.HouseDAO;

@WebServlet("/DemoHouseJNDIAction")
public class DemoHouseJNDIAction extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private WebApplicationContext context;
	
	public void init() throws ServletException {
		ServletContext application = getServletContext();
		context = WebApplicationContextUtils.getWebApplicationContext(application);
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processAction(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processAction(request, response);

	}

	private void processAction(HttpServletRequest request, HttpServletResponse response) throws IOException {
//		response.setContentType("text/html; charset=UTF-8");
//		PrintWriter out = response.getWriter();
//		try {
//			HouseDAO hDAO=(HouseDAO)context.getBean("HouseDAO");
//			House hBean1 = hDAO.select(1001);
//			out.write("id : " + hBean1.getHouseid() + "<br>" + "name" + hBean1.getHousename());
//			
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		
//		
//		
//		
//		out.close();
		
	}

}
