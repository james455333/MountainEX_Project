package test1.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.model.naming.ImplicitNameSource;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import test1.model.House;
import test1.model.HouseBean;
import test1.model.HouseBeanDAO;
import test1.model.HouseBeanService;
import test1.model.HouseDAO;

@WebServlet("/DemoHouseBeanJNDIAction1")
public class DemoHouseBeanSessionFactoryJndiAction1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private WebApplicationContext context;

	public void init() throws ServletException {
		ServletContext application = getServletContext();
		context = WebApplicationContextUtils.getWebApplicationContext(application);

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processAction(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processAction(request, response);

	}

	private void processAction(HttpServletRequest request, HttpServletResponse response) throws IOException {
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		SessionFactory sessionFactory = (SessionFactory) context.getBean("sessionFactory");
		Session session = sessionFactory.getCurrentSession();
		;
		try {

			session.beginTransaction();
			int id = 1001;
			HouseBean houseBean1 = session.get(HouseBean.class, id);

			if (houseBean1 != null) {

				out.write(houseBean1.getHouseid() + " : " + houseBean1.getHousename());

			} else {

				out.write("No Such ID : " + id);

			}

			HouseBeanDAO hDao = (HouseBeanDAO) context.getBean("houseBeanDao");
			int id2 = 1010;
			HouseBean hBean2 = hDao.select(id2);
			if (hBean2 != null) {
				out.write(hBean2.getHouseid() + " : " + hBean2.getHousename());

			} else {

				out.write("No Such ID : " + id2);

			}
			
			HouseBeanService hService=(HouseBeanService)context.getBean("houseBeanService");
			HouseBean hBean3 = new HouseBean(1005,"GreenHouse");
			hService.insert(hBean3);
			
			session.getTransaction().commit();

		} catch (Exception e) {
			session.getTransaction().rollback();
			e.printStackTrace();
		}

	}

}
