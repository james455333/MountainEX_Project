package run;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

public class Run {

	public static void main(String[] args) {
		
		try (
				FileInputStream fis = new FileInputStream("C:\\DataSource\\workspace\\csv\\data\\shopitem_UTF8.csv");
				InputStreamReader isr = new InputStreamReader(fis);
				BufferedReader bufferedReader = new BufferedReader(isr);
				){
			
			CSVParser parser = CSVFormat.EXCEL.withHeader().parse(bufferedReader);
			List<CSVRecord> records = parser.getRecords();
			
			for (CSVRecord csvRecord : records) {
				
				System.out.println("img" + csvRecord.get(1) + "Desc" + csvRecord.get(1));
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

}
